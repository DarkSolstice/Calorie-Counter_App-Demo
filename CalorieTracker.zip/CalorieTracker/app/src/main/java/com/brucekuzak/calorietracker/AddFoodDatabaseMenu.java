package com.brucekuzak.calorietracker;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;


public class AddFoodDatabaseMenu extends ActionBarActivity {
    boolean completeChecker;
    private int intItemCalories;
    private double doubleItemProteins;
    private double doubleItemFats;
    private double doubleItemSugars;
    private EditText itemQuantity;
    private EditText itemCalories;
    private EditText itemCarbs;
    private EditText itemProteins;
    private EditText itemFats;
    private EditText itemName;

    Thread addItem = new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                String quantityChecker = itemQuantity.getText().toString();
                String calorieChecker = itemCalories.getText().toString();
                String carbsChecker = itemCarbs.getText().toString();
                String proteinChecker = itemProteins.getText().toString();
                String fatsChecker = itemFats.getText().toString();
                String nameChecker = itemName.getText().toString();
                completeChecker = false;
                // if a field is missing the checker becomes false and the database will not be updated
                if (!(quantityChecker.isEmpty() || calorieChecker.isEmpty() || carbsChecker.isEmpty() || proteinChecker.isEmpty() || fatsChecker.isEmpty() || nameChecker.isEmpty())) {
                    completeChecker = true;
                    intItemCalories = Integer.parseInt(calorieChecker);
                    doubleItemProteins = Double.parseDouble(proteinChecker);
                    doubleItemFats = Double.parseDouble(fatsChecker);
                    doubleItemSugars = Double.parseDouble(carbsChecker);
                }
                if (((RadioButton) findViewById(R.id.database_radioButtonG)).isChecked()) {
                    quantityChecker += "g";
                }
                else if (((RadioButton) findViewById(R.id.database_radioButtonL)).isChecked()) {
                    quantityChecker += "ml";
                }
                else if (((RadioButton) findViewById(R.id.database_radioButtonU)).isChecked()) {
                    quantityChecker += "unit";
                }
                else {
                    completeChecker = false;
                }
                if (completeChecker) {
                    MainMenu.db.insertCalorieGuide(nameChecker, quantityChecker, intItemCalories, doubleItemProteins, doubleItemSugars, doubleItemFats, "", "");
                }
            } catch (Exception ioe) {
            }
        }
    });
    Thread updateItem = new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                String quantityChecker = itemQuantity.getText().toString();
                String calorieChecker = itemCalories.getText().toString();
                String carbsChecker = itemCarbs.getText().toString();
                String proteinChecker = itemProteins.getText().toString();
                String fatsChecker = itemFats.getText().toString();
                String nameChecker = itemName.getText().toString();
                completeChecker = false;
                // if a field is missing the checker becomes false and the database will not be updated
                if (!(quantityChecker.isEmpty() || calorieChecker.isEmpty() || carbsChecker.isEmpty() || proteinChecker.isEmpty() || fatsChecker.isEmpty() || nameChecker.isEmpty())) {
                    completeChecker = true;
                    intItemCalories = Integer.parseInt(calorieChecker);
                    doubleItemProteins = Double.parseDouble(proteinChecker);
                    doubleItemFats = Double.parseDouble(fatsChecker);
                    doubleItemSugars = Double.parseDouble(carbsChecker);
                }
                if (((RadioButton) findViewById(R.id.database_radioButtonG)).isChecked()) {
                    quantityChecker += "g";
                }
                else if (((RadioButton) findViewById(R.id.database_radioButtonL)).isChecked()) {
                    quantityChecker += "ml";
                }
                else if (((RadioButton) findViewById(R.id.database_radioButtonU)).isChecked()) {
                    quantityChecker += "unit";
                }
                else {
                    completeChecker = false;
                }
                if (completeChecker) {
                    MainMenu.db.updateCalorieGuide(nameChecker, quantityChecker, intItemCalories, doubleItemProteins, doubleItemSugars, doubleItemFats);
                }
            } catch (Exception ioe) {
            }
        }
    });
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_food_database_menu);
        itemQuantity = (EditText)findViewById(R.id.database_QuantityAnswer);
        itemCalories = (EditText)findViewById(R.id.database_CalorieAnswer);
        itemProteins = (EditText)findViewById(R.id.editText_AddDatabase_Proteins);
        itemFats = (EditText)findViewById(R.id.editText_AddDatabase_Fats);
        itemCarbs = (EditText)findViewById(R.id.editText_AddDatabase_Sugars);
        itemName = (EditText)findViewById(R.id.database_NameAnswer);
        if(getIntent().getIntExtra("Opener",-1)==1){
            //do nothing evrything is set in the XML files
        }
        else if(getIntent().getIntExtra("Opener",-1)==0){
            Button editor = (Button)findViewById(R.id.database_buttonAdd);
            editor.setText("Edit");
            FoodItem inEditingItem = EditMenu.selectedFoodItemObject;
            itemName.setText(inEditingItem.getFoodName());
            itemQuantity.setText(Integer.toString(inEditingItem.getFoodSizeAsInt()));
            itemCalories.setText(Integer.toString(inEditingItem.getFoodCalories()));
            itemProteins.setText(Double.toString(inEditingItem.getFoodProteins()));
            itemFats.setText(Double.toString(inEditingItem.getFoodFats()));
            itemCarbs.setText(Double.toString(inEditingItem.getFoodCarbs()));
            int buttonValue = inEditingItem.getUnitType();
            switch(buttonValue){
                case 0:((RadioButton) findViewById(R.id.database_radioButtonG)).setChecked(true);break;
                case 1:((RadioButton) findViewById(R.id.database_radioButtonL)).setChecked(true);break;
                case 2:((RadioButton) findViewById(R.id.database_radioButtonU)).setChecked(true);break;
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.action_bar_everywhere, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_help: {
                AlertDialog.Builder helpPopup = new AlertDialog.Builder(this);
                TextView alertTitle = new TextView(this);
                alertTitle.setText("Adding Food To The App");
                alertTitle.setGravity(Gravity.CENTER_HORIZONTAL);
                alertTitle.setTextSize(20);
                helpPopup.setCustomTitle(alertTitle);
                TextView information = new TextView(this);
                information.setText(R.string.HelpMenu_UsingDatabaseAdd);
                information.setGravity(Gravity.CENTER);
                information.setTextSize(16);
                helpPopup.setView(information);
                helpPopup.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                helpPopup.show();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    public void addDatabase(View v) {
        if(getIntent().getIntExtra("Opener",-1)==1){
            if(MainMenu.db.checkCalorieGuide(itemName.getText().toString()))
            {
                Toast alreadyAdded = Toast.makeText(this, "Similar Item Name Exist", Toast.LENGTH_SHORT);
                alreadyAdded.show();
            }
            else
            {
                addItem.run();
                if (!completeChecker) {
                    Toast added = Toast.makeText(this, "Incomplete Form", Toast.LENGTH_SHORT);
                    added.show();
                } else {
                    //reset Form To No Values;
                    itemQuantity.setText("");
                    itemCalories.setText("");
                    itemProteins.setText("");
                    itemFats.setText("");
                    itemCarbs.setText("");
                    itemName.setText("");
                    Toast added = Toast.makeText(this, "Added Successfully", Toast.LENGTH_SHORT);
                    added.show();
                }
            }
        }
        else if(getIntent().getIntExtra("Opener",-1)==0){
            updateItem.run();
            if (!completeChecker) {
                Toast added = Toast.makeText(this, "Incomplete Form", Toast.LENGTH_SHORT);
                added.show();
            } else {
                Toast added = Toast.makeText(this, "Edited Successfully", Toast.LENGTH_SHORT);
                added.show();
                Intent returnToEditMenu = new Intent(AddFoodDatabaseMenu.this,EditMenu.class);
                startActivity(returnToEditMenu);
            }
        }
    }
}
