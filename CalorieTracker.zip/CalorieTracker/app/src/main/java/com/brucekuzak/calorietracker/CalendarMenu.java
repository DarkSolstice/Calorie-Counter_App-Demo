package com.brucekuzak.calorietracker;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;


public class CalendarMenu extends ActionBarActivity {
    public static String formattedDateToBePassed;
    public static String dateString;
    final private String caloriesForList = "Calories : ";
    final private String proteinsForList = "Proteins : ";
    final private String sugarForList = "Sugar : ";
    final private String fatsForList = "Fats : ";
    ArrayAdapter adapter;
    ArrayList<String> dateArray = new ArrayList<>();
    private String formattedDate;
    private double[] dailyTotal;

    Thread listUpdater = new Thread(new Runnable() {
        @Override
        public void run() {
            String[] tempStorage = dateString.split("/");
            int dayOfMonth = Integer.parseInt(tempStorage[0]);
            int month = Integer.parseInt(tempStorage[1]);
            int year = Integer.parseInt(tempStorage[2]);
            if (dayOfMonth <= 9 && month <= 9) {
                formattedDate = "0" + dayOfMonth + "0" + month + "" + year;
            } else if (dayOfMonth <= 9) {
                formattedDate = "0" + dayOfMonth + "" + month + "" + year;
            } else if (month <= 9) {
                formattedDate = dayOfMonth + "0" + month + "" + year;
            } else {
                formattedDate = dayOfMonth + "" + month + "" + year;
            }
            try {
                dailyTotal = MainMenu.db.getDateInfoSum(formattedDate);
                dateArray.clear();
                double userCarbs = MainMenu.userInfo.getInt("userCarbs", -1);
                double userFats = MainMenu.userInfo.getInt("userFats", -1);
                double userProtein = MainMenu.userInfo.getInt("userProtein", -1);
                double userCalories = MainMenu.userInfo.getInt("userCalories", -1);
                if (userCalories != -1) {
                    if (userCarbs != -1) {
                        userCarbs = (userCalories * (userCarbs / 100.0)) / 4;
                    }
                    if (userFats != -1) {
                        userFats = (userCalories * (userFats / 100.0)) / 9;
                    }
                    if (userProtein != -1) {
                        userProtein = (userCalories * (userProtein / 100.0)) / 4;
                    }
                }
                DecimalFormat df = new DecimalFormat("0.00");
                dateArray.add(caloriesForList + (int) dailyTotal[0] + " (" + df.format(dailyTotal[0] / userCalories * 100) + "%)");
                dateArray.add(proteinsForList + df.format(dailyTotal[1]) + " (" + df.format(dailyTotal[1] / userProtein * 100) + "%)");
                dateArray.add(sugarForList + df.format(dailyTotal[2]) + " (" + df.format(dailyTotal[2] / userCarbs * 100) + "%)");
                dateArray.add(fatsForList + df.format(dailyTotal[3]) + " (" + df.format(dailyTotal[3] / userFats * 100) + "%)");
            } catch (Exception ioe) {
            }
        }
    });

    public class OnSwipeTouchListener implements View.OnTouchListener {

        private final GestureDetector gestureDetector;

        public OnSwipeTouchListener(Context context) {
            gestureDetector = new GestureDetector(context, new GestureListener());
        }

        public void onSwipeLeft() {
        }

        public void onSwipeRight() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            return gestureDetector.onTouchEvent(event);
        }

        private final class GestureListener extends GestureDetector.SimpleOnGestureListener {

            private static final int SWIPE_DISTANCE_THRESHOLD = 100;
            private static final int SWIPE_VELOCITY_THRESHOLD = 100;

            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                float distanceX = e2.getX() - e1.getX();
                float distanceY = e2.getY() - e1.getY();
                if (Math.abs(distanceX) > Math.abs(distanceY) && Math.abs(distanceX) > SWIPE_DISTANCE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                    if (distanceX > 0)
                        onSwipeRight();
                    else
                        onSwipeLeft();
                    return true;
                }
                return false;
            }
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calendar_menu);
        CalendarView calendarView = (CalendarView) findViewById(R.id.calendarView_holder);
        Calendar rightNow = Calendar.getInstance();
        ListView myCalendarList = (ListView) findViewById(R.id.listView_calendar);
        myCalendarList.setOnTouchListener(new OnSwipeTouchListener(this) {
            @Override
            public void onSwipeLeft() {
                Intent opener = new Intent(CalendarMenu.this, EditMenu.class);
                //Load selected date into intent for ease of purpose later on
                opener.putExtra(dateString, dateString);
                //passed for ease of purpose to add later and not have to reformat;
                opener.putExtra(formattedDateToBePassed, formattedDate);
                startActivity(opener);
            }
        });

        //setup at current date with variables set if someone decides to click edit without hitting the date again.
        int currentMonth = rightNow.get(rightNow.MONTH) + 1;
        int currentDay = rightNow.get(rightNow.DAY_OF_MONTH);
        int currentYear = rightNow.get(rightNow.YEAR);
        dateString = currentDay + "/" + currentMonth + "/" + currentYear;
        TextView DailyDate = (TextView) findViewById(R.id.textView_DailyInfo);
        DailyDate.setText(dateString);
        this.adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dateArray);
        myCalendarList.setAdapter(adapter);
        listUpdater.run();
        adapter.notifyDataSetChanged();

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                dateString = dayOfMonth + "/" + (month + 1) + "/" + year;
                TextView DailyDate = (TextView) findViewById(R.id.textView_DailyInfo);
                DailyDate.setText(dateString);
                listUpdater.run();
                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    protected void onResume() {
        listUpdater.run();
        adapter.notifyDataSetChanged();
        super.onResume();
    }

    //Method to add XML settings to action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.action_bar_everywhere, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //Method to handle Action Bar Clicks
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.action_help: {
                AlertDialog.Builder helpPopup = new AlertDialog.Builder(this);
                TextView alertTitle = new TextView(this);
                alertTitle.setText("Using The Calendar");
                alertTitle.setGravity(Gravity.CENTER_HORIZONTAL);
                alertTitle.setTextSize(20);
                helpPopup.setCustomTitle(alertTitle);
                TextView information = new TextView(this);
                information.setText(R.string.HelpMenu_UsingCalendar);
                information.setGravity(Gravity.CENTER);
                information.setTextSize(16);
                helpPopup.setView(information);
                helpPopup.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                helpPopup.show();
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}