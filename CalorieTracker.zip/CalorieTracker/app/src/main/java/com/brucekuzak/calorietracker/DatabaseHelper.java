package com.brucekuzak.calorietracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import com.jjoe64.graphview.series.DataPoint;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * Created by bruce on 2015-06-13.
 */
public class DatabaseHelper extends SQLiteOpenHelper {
	
	//class to help me organise the database stuff
    private static final String DATABASE_NAME = "CalorieGuide.db";
    private static final int DATABASE_VERSION = 1;
    private static final String CSV_FILENAME = "CalorieTrackerInfo.csv";


    private static final String TABLE_NAME_CalorieGuide = "CalorieGuide";
    private static final String TABLE_NAME_CalendarInfo = "CalendarInfo";
    private static final String COLUMN_Food = "Food";
    private static final String COLUMN_Size = "Size";
    private static final String COLUMN_Calories = "Calories";
    private static final String COLUMN_Proteins = "Proteins";
    private static final String COLUMN_Sugar = "Sugar";
    private static final String COLUMN_Fats = "Fats";
    private static final String COLUMN_Date = "Date";
    private static final String COLUMN_DescriptionMetric = "DescriptionMetric";
    private static final String COLUMN_DescriptionImperial = "DescriptionImperial";
    // database path
    private static String DATABASE_PATH;
    private final Context context;
    private SQLiteDatabase database;


    public DatabaseHelper(Context ctx) {
        super(ctx, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = ctx;
        DATABASE_PATH = context.getFilesDir().getParentFile().getPath()
                + "/databases/";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this should ensure that the user doesnt lose his custom data when updating the database.
        SQLiteDatabase temp = this.database;
        this.database = db;
        try {
            InputStream in = context.getAssets().open(CSV_FILENAME);
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            String currentLine = reader.readLine();
            while (currentLine != null) {
                String[] splitInfo = currentLine.split(";");
                // food = 1, size = 2, calories = 3, proteins = 4, sugar = 5, fats = 6, descriptionMetric = 7 descriptionImperial = 8
                //deletes the old and adds the new info
                // The LauncherLogo.db is used to avoid the locked database error and will always be updated in the launcherLogo anyways as this is the first instance of the db launch.
                if (checkCalorieGuide(splitInfo[1])) {
                    deleteCalorieGuide(splitInfo[1]);
                }
                insertCalorieGuide(splitInfo[1], splitInfo[2], Integer.parseInt(splitInfo[3]), Double.parseDouble(splitInfo[4]), Double.parseDouble(splitInfo[5]), Double.parseDouble(splitInfo[6]), splitInfo[7], splitInfo[8]);
                currentLine = reader.readLine();
            }
            this.database = temp;
        } catch (Exception ioe) {
        }
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //do nothing;
    }

    public void create() throws IOException {
        boolean check = checkDataBase();

        SQLiteDatabase db_Read = null;

        // Creates empty database default system path
        db_Read = this.getWritableDatabase();
        db_Read.close();
        try {
            if (!check) {
                copyDataBase();
            }
        } catch (IOException e) {
            throw new Error("Error copying database");
        }
    }

    public boolean checkDataBase() {
        SQLiteDatabase checkDB = null;
        boolean answer = false;
        try {
            String myPath = DATABASE_PATH + DATABASE_NAME;
            checkDB = SQLiteDatabase.openDatabase(myPath, null,
                    SQLiteDatabase.OPEN_READONLY);
        } catch (SQLiteException e) {

        }

        if (checkDB != null) {
            checkDB.close();
            answer = true;
        }
        return answer;
    }

    private void copyDataBase() throws IOException {

        // Open your local db as the input stream
        InputStream myInput = context.getAssets().open(DATABASE_NAME);

        // Path to the just created empty db
        String outFileName = DATABASE_PATH + DATABASE_NAME;

        // Open the empty db as the output stream
        OutputStream myOutput = new FileOutputStream(outFileName);

        // transfer bytes from the inputfile to the outputfile
        byte[] buffer = new byte[1024];
        int length;
        while ((length = myInput.read(buffer)) > 0) {
            myOutput.write(buffer, 0, length);
        }

        // Close the streams
        myOutput.flush();
        myOutput.close();
        myInput.close();

    }

    public void open() throws SQLException {
        String myPath = DATABASE_PATH + DATABASE_NAME;
        database = SQLiteDatabase.openDatabase(myPath, null,
                SQLiteDatabase.OPEN_READWRITE);
    }

    @Override
    public synchronized void close() {
        if (database != null)
            database.close();
        super.close();
    }

    //added july 7th
    public void insertCalorieGuide(String food, String size, int calories, double protein, double sugar, double fats, String descriptionMetric, String descriptionImperial) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(COLUMN_Food, food);
        initialValues.put(COLUMN_Size, size);
        initialValues.put(COLUMN_Calories, calories);
        initialValues.put(COLUMN_Proteins, protein);
        initialValues.put(COLUMN_Sugar, sugar);
        initialValues.put(COLUMN_Fats, fats);
        initialValues.put(COLUMN_DescriptionMetric, descriptionMetric);
        initialValues.put(COLUMN_DescriptionImperial, descriptionImperial);
        database.insert(TABLE_NAME_CalorieGuide, null, initialValues);
    }

    public void insertCalendarInfo(String date, FoodItem item, double multiplier) {
        ContentValues initialValues = new ContentValues();
        DecimalFormat df = new DecimalFormat("0.00");
        initialValues.put(COLUMN_Food, item.getFoodName());
        initialValues.put(COLUMN_Date, date);
        initialValues.put(COLUMN_Calories, (int) (item.getFoodCalories() * multiplier));
        initialValues.put(COLUMN_Proteins, Double.parseDouble(df.format(item.getFoodProteins() * multiplier)));
        initialValues.put(COLUMN_Sugar, Double.parseDouble(df.format(item.getFoodCarbs() * multiplier)));
        initialValues.put(COLUMN_Fats, Double.parseDouble(df.format(item.getFoodFats() * multiplier)));
        database.insert(TABLE_NAME_CalendarInfo, null, initialValues);
    }

    public void updateCalorieGuide(String food, String size, int calories, double protein, double sugar, double fats){
        String sqlQuery = "Update " + TABLE_NAME_CalorieGuide+" SET "+
                COLUMN_Size+" = \'"+size +"\'," +
                COLUMN_Calories+" = " + calories +","+
                COLUMN_Proteins+" = " + protein +","+
                COLUMN_Sugar+" = " + sugar +","+
                COLUMN_Fats+" = " + fats +" Where "+ COLUMN_Food + " = \'"+ food + "\'";
        database.execSQL(sqlQuery);
    }

    public void deleteCalendarInfo(String date, String food, int calories) {
        String sqlQuery = "DELETE From " + TABLE_NAME_CalendarInfo + " WHERE Date = " + date + " AND Food = \'" + food + "\'";
        database.execSQL(sqlQuery);
    }

    public void deleteCalorieGuide(String food) {
        String sqlQuery = "DELETE From " + TABLE_NAME_CalorieGuide + " WHERE Food = \'" + food + "\'";
        database.execSQL(sqlQuery);
    }

    public boolean checkCalorieGuide(String food) {
        boolean returnValue = false;
        String sqlQuery = "SELECT * FROM " + TABLE_NAME_CalorieGuide + " WHERE Food = \'" + food + "\'";
        Cursor checker = database.rawQuery(sqlQuery, null);
        if (checker.moveToFirst()) {
            returnValue = true;
        }

        return returnValue;
    }

    public ArrayList<FoodItem> fullCalorieGuide() throws SQLException {

        //Activate Cursor with all date from my calorieGuide database
        Cursor mCursor = database.rawQuery("SELECT * FROM CalorieGuide ORDER BY Food ASC", null);
        //Activate Array for array adapter with exactly enough room = number of rows in table
        ArrayList<FoodItem> returnValue = new ArrayList<>();
        //activate the arrayAdapter with the passed context from edit menu.class
        mCursor.moveToFirst();
        do {
            String name = mCursor.getString(mCursor.getColumnIndex(COLUMN_Food));
            String size = mCursor.getString(mCursor.getColumnIndex(COLUMN_Size));
            int calories = mCursor.getInt(mCursor.getColumnIndex(COLUMN_Calories));
            double protein = mCursor.getDouble(mCursor.getColumnIndex(COLUMN_Proteins));
            double sugar = mCursor.getDouble(mCursor.getColumnIndex(COLUMN_Sugar));
            double fat = mCursor.getDouble(mCursor.getColumnIndex(COLUMN_Fats));
            String descriptionMetric = mCursor.getString(mCursor.getColumnIndex(COLUMN_DescriptionMetric));
            String descriptionImperial = mCursor.getString(mCursor.getColumnIndex(COLUMN_DescriptionImperial));
            //Create the food item with the database info
            FoodItem tempToStoreInAdapterArray = new FoodItem(name, size, calories, protein, sugar, fat, descriptionMetric, descriptionImperial);
            returnValue.add(tempToStoreInAdapterArray);
        } while (mCursor.moveToNext());

        return returnValue;
    }

    public ArrayList<FoodItem> filteredCalorieGuide(String filter) throws SQLException {
        //Activate Cursor with all date from my calorieGuide database
        String sqlQuery = "SELECT * FROM CalorieGuide WHERE Food LIKE \'" + "%" + filter + "%" + "\' ORDER BY Food ASC";
        Cursor mCursor = database.rawQuery(sqlQuery, null);
        //Activate Array for array adapter with exactly enough room = number of rows in table
        ArrayList<FoodItem> returnValue = new ArrayList<>();
        //activate the arrayAdapter with the passed context from edit menu.class
        if (mCursor.getCount() == 0) {
            return null;
        }
        mCursor.moveToFirst();
        do {
            String name = mCursor.getString(mCursor.getColumnIndex(COLUMN_Food));
            String size = mCursor.getString(mCursor.getColumnIndex(COLUMN_Size));
            int calories = mCursor.getInt(mCursor.getColumnIndex(COLUMN_Calories));
            double protein = mCursor.getDouble(mCursor.getColumnIndex(COLUMN_Proteins));
            double sugar = mCursor.getDouble(mCursor.getColumnIndex(COLUMN_Sugar));
            double fat = mCursor.getDouble(mCursor.getColumnIndex(COLUMN_Fats));
            String descriptionMetric = mCursor.getString(mCursor.getColumnIndex(COLUMN_DescriptionMetric));
            String descriptionImperial = mCursor.getString(mCursor.getColumnIndex(COLUMN_DescriptionImperial));
            //Create the food item with the database info
            FoodItem tempToStoreInAdapterArray = new FoodItem(name, size, calories, protein, sugar, fat, descriptionMetric, descriptionImperial);
            returnValue.add(tempToStoreInAdapterArray);
        } while (mCursor.moveToNext());

        return returnValue;
    }

    public double[] getDateInfoSum(String date) throws SQLException {
        double[] answer = new double[4];
        Cursor mCursor = database.rawQuery("SELECT SUM(" + this.COLUMN_Calories + ") FROM " + this.TABLE_NAME_CalendarInfo + " WHERE " + this.COLUMN_Date + " = " + date, null);
        if (mCursor.moveToFirst()) {
            answer[0] = mCursor.getDouble(mCursor.getColumnIndex("SUM(" + this.COLUMN_Calories + ")"));
        }
        mCursor = database.rawQuery("SELECT SUM(" + COLUMN_Proteins + ") FROM " + this.TABLE_NAME_CalendarInfo + " WHERE " + this.COLUMN_Date + " = " + date, null);
        if (mCursor.moveToFirst()) {
            answer[1] = mCursor.getDouble(mCursor.getColumnIndex("SUM(" + COLUMN_Proteins + ")"));
        }
        mCursor = database.rawQuery("SELECT SUM(" + COLUMN_Sugar + ") FROM " + this.TABLE_NAME_CalendarInfo + " WHERE " + this.COLUMN_Date + " = " + date, null);
        if (mCursor.moveToFirst()) {
            answer[2] = mCursor.getDouble(mCursor.getColumnIndex("SUM(" + COLUMN_Sugar + ")"));
        }
        mCursor = database.rawQuery("SELECT SUM(" + COLUMN_Fats + ") FROM " + this.TABLE_NAME_CalendarInfo + " WHERE " + this.COLUMN_Date + " = " + date, null);
        if (mCursor.moveToFirst()) {
            answer[3] = mCursor.getDouble(mCursor.getColumnIndex("SUM(" + COLUMN_Fats + ")"));
        }
        return answer;
    }

    //added June 30th
    public ArrayList<FoodItem> getSpecificDateItems(String date) throws SQLException {
        ArrayList<FoodItem> returnValue = new ArrayList<>();
        String sqlQuery = "SELECT * FROM CalendarInfo WHERE Date = " + date;
        Cursor mCursor = database.rawQuery(sqlQuery, null);
        FoodItem temp;
        mCursor.moveToFirst();
        do {
            String name = mCursor.getString(mCursor.getColumnIndex(COLUMN_Food));
            int calories = mCursor.getInt(mCursor.getColumnIndex(COLUMN_Calories));
            double protein = mCursor.getDouble(mCursor.getColumnIndex(COLUMN_Proteins));
            double sugar = mCursor.getDouble(mCursor.getColumnIndex(COLUMN_Sugar));
            double fat = mCursor.getDouble(mCursor.getColumnIndex(COLUMN_Fats));
            temp = new FoodItem(name, null, calories, protein, sugar, fat, null, null);
            returnValue.add(temp);
        } while (mCursor.moveToNext());
        return returnValue;
    }

    //format of month passed has to be MM
    public DataPoint[] getMonthDailyCalorieSum(String month, int daysInMonth, String year) throws SQLException {
        DataPoint[] returnValues = new DataPoint[daysInMonth];
        String search;
        for (int i = 1; i < daysInMonth + 1; i++) {
            //Toget the format of DDMM
            if (i <= 9) {
                search = "0" + i + month + year;
            } else {
                search = i + month + year;
            }
            //GET calorie Sum for the DDMM
            Cursor mCursor = database.rawQuery("SELECT SUM(" + this.COLUMN_Calories + ") FROM " + this.TABLE_NAME_CalendarInfo + " WHERE " + this.COLUMN_Date + " = " + search, null);
            if (mCursor.moveToFirst()) {
                //SETUP THE DATA POINT X=Date Y=CalorieTotal
                int dailyCalorieValue = mCursor.getInt(mCursor.getColumnIndex("SUM(" + this.COLUMN_Calories + ")"));
                DataPoint temp = new DataPoint(i, dailyCalorieValue);
                returnValues[i - 1] = temp;
            } else {
                DataPoint temp = new DataPoint(i, 0);
                returnValues[i - 1] = temp;
            }
            mCursor.close();
        }
        return returnValues;
    }

    public DataPoint[] getMonthDailyProteinSum(String month, int daysInMonth, String year) throws SQLException {
        DataPoint[] returnValues = new DataPoint[daysInMonth];
        String search;
        for (int i = 1; i < daysInMonth + 1; i++) {
            //Toget the format of DDMM
            if (i <= 9) {
                search = "0" + i + month + year;
            } else {
                search = i + month + year;
            }
            //GET calorie Sum for the DDMM
            Cursor mCursor = database.rawQuery("SELECT SUM(" + this.COLUMN_Proteins + ") FROM " + this.TABLE_NAME_CalendarInfo + " WHERE " + this.COLUMN_Date + " = " + search, null);
            if (mCursor.moveToFirst()) {
                //SETUP THE DATA POINT X=Date Y=CalorieTotal
                int dailyCalorieValue = mCursor.getInt(mCursor.getColumnIndex("SUM(" + this.COLUMN_Proteins + ")"));
                DataPoint temp = new DataPoint(i, dailyCalorieValue);
                returnValues[i - 1] = temp;
            } else {
                DataPoint temp = new DataPoint(i, 0);
                returnValues[i - 1] = temp;
            }
            mCursor.close();
        }
        return returnValues;
    }

    public DataPoint[] getMonthDailySugarSum(String month, int daysInMonth, String year) throws SQLException {
        DataPoint[] returnValues = new DataPoint[daysInMonth];
        String search;
        for (int i = 1; i < daysInMonth + 1; i++) {
            //Toget the format of DDMM
            if (i <= 9) {
                search = "0" + i + month + year;
            } else {
                search = i + month + year;
            }
            //GET calorie Sum for the DDMM
            Cursor mCursor = database.rawQuery("SELECT SUM(" + this.COLUMN_Sugar + ") FROM " + this.TABLE_NAME_CalendarInfo + " WHERE " + this.COLUMN_Date + " = " + search, null);
            if (mCursor.moveToFirst()) {
                //SETUP THE DATA POINT X=Date Y=CalorieTotal
                int dailyCalorieValue = mCursor.getInt(mCursor.getColumnIndex("SUM(" + this.COLUMN_Sugar + ")"));
                DataPoint temp = new DataPoint(i, dailyCalorieValue);
                returnValues[i - 1] = temp;
            } else {
                DataPoint temp = new DataPoint(i, 0);
                returnValues[i - 1] = temp;
            }
            mCursor.close();
        }
        return returnValues;
    }

    public DataPoint[] getMonthDailyFatSum(String month, int daysInMonth, String year) throws SQLException {
        DataPoint[] returnValues = new DataPoint[daysInMonth];
        String search;
        for (int i = 1; i < daysInMonth + 1; i++) {
            //Toget the format of DDMM
            if (i <= 9) {
                search = "0" + i + month + year;
            } else {
                search = i + month + year;
            }
            //GET calorie Sum for the DDMM
            Cursor mCursor = database.rawQuery("SELECT SUM(" + this.COLUMN_Fats + ") FROM " + this.TABLE_NAME_CalendarInfo + " WHERE " + this.COLUMN_Date + " = " + search, null);
            if (mCursor.moveToFirst()) {
                //SETUP THE DATA POINT X=Date Y=CalorieTotal
                int dailyCalorieValue = mCursor.getInt(mCursor.getColumnIndex("SUM(" + this.COLUMN_Fats + ")"));
                DataPoint temp = new DataPoint(i, dailyCalorieValue);
                returnValues[i - 1] = temp;
            } else {
                DataPoint temp = new DataPoint(i, 0);
                returnValues[i - 1] = temp;
            }
            mCursor.close();
        }
        return returnValues;
    }

    public int getNumberOfDaysEnteredInMonth(String month, int daysInMonth, String year)throws  SQLException {
        int returnValue = 0;
        for (int i = 1; i < daysInMonth + 1; i++) {
            //Toget the format of DDMM
            String search;
            if (i <= 9) {
                search = "0" + i + month + year;
            } else {
                search = i + month + year;
            }
            //GET calorie Sum for the DDMM
            Cursor mCursor = database.rawQuery("SELECT * FROM " + this.TABLE_NAME_CalendarInfo + " WHERE " + this.COLUMN_Date + " = " + search, null);
            if (mCursor.getCount()>0) {
                returnValue++;
            }
            mCursor.close();
        }
        return returnValue;
    }
}