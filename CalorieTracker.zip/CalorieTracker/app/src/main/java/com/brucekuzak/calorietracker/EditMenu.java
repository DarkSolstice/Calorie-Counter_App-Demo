package com.brucekuzak.calorietracker;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AlertDialog;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;


public class EditMenu extends ActionBarActivity {

    //View shared across methods
    ListView CalorieList;
    ListView dailyItemsList;

    //Shared Important variables;
    private String dateReceived;
    private String formatDateReceived;
    private int popupDefiner;
    private String searchString;

    //Every variable shared in this activity and threads for the lists
    private ArrayAdapter<FoodItem> foodAdapter;
    private ArrayAdapter dayAdapter;
    private ArrayList<FoodItem> filteredArray;
    private ArrayList<FoodItem> dailyItems = new ArrayList<>();

    //variable to help add to database correctly;
    private double selectedFoodPortion;
    private String selectedFoodName;
    private int selectedFoodCalories;
    private double selectedUserPortion;
    public static FoodItem selectedFoodItemObject;

    //variables for dialog menu
    private String popupHint;
    private String foodDescription;
    private AlertDialog.Builder builder;
    private EditText popupView;

    Thread getFullDatabase = new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                //intially its not filtered but this saves memory by not creating 2 arrays in the variables
                //this needs to be run everytime and not cache from the other menu because people need might add stuff.
                //not speed up was obtained really by creating the arrayList in the mainmenu class(may even save memory because the array isnt constantly there).
                filteredArray = MainMenu.db.fullCalorieGuide();
            } catch (Exception ioe) {
            }
        }
    });
    //Thread to retrieve the items ate on the specific date of the device
    Thread getDailyItems = new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                dailyItems = MainMenu.db.getSpecificDateItems(formatDateReceived);
            } catch (Exception ioe) {
            }
        }
    });

    //will constantly update the list as the search field is updated;
    //this is ran in a seperate thread to avoid locking up the app
    Thread listMonitor = new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                filteredArray = MainMenu.db.filteredCalorieGuide(searchString);
                foodAdapter.clear();
                if (!(filteredArray == null)) {
                    //set the adapter to the filtered search
                    foodAdapter.addAll(filteredArray);
                }
                foodAdapter.notifyDataSetChanged();
            } catch (Exception ioe) {
            }
        }
    });

    Thread addCalendarInfoFood = new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                double multiplier = selectedUserPortion / selectedFoodPortion;
                MainMenu.db.insertCalendarInfo(formatDateReceived, selectedFoodItemObject, multiplier);
                DecimalFormat df = new DecimalFormat("0.00");
                Double addProtein = selectedFoodItemObject.getFoodProteins() * multiplier;
                Double addFats = selectedFoodItemObject.getFoodFats() * multiplier;
                Double addSugars = selectedFoodItemObject.getFoodCarbs() * multiplier;
                FoodItem addedItem = new FoodItem(selectedFoodItemObject.getFoodName(), null, (int) (selectedFoodItemObject.getFoodCalories() * multiplier), Double.parseDouble(df.format(addProtein)), Double.parseDouble(df.format(addSugars)), Double.parseDouble(df.format(addFats)), "", "");
                if (dailyItems.isEmpty()) {
                    //add items to the FoodItemArray initialize the arrayAdapter and set it to the listView. (only happens when no items are recorded for that day
                    dailyItems.add(addedItem);
                    dailyItemsList.setAdapter(dayAdapter);
                } else {
                    dayAdapter.add(addedItem);
                    dayAdapter.notifyDataSetChanged();
                }
            } catch (Exception ioe) {
            }
        }
    });

    Thread removeDailyItem = new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                MainMenu.db.deleteCalendarInfo(formatDateReceived, selectedFoodName, selectedFoodCalories);
                dayAdapter.remove(selectedFoodItemObject);
                dayAdapter.notifyDataSetChanged();
            } catch (Exception ioe) {
            }
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_menu);

        getFullDatabase.run();

        //receive date from intent
        Intent received = getIntent();
        dateReceived = received.getStringExtra(CalendarMenu.dateString);
        formatDateReceived = received.getStringExtra(CalendarMenu.formattedDateToBePassed);
        TextView title = (TextView) findViewById(R.id.textView_EditTitle);
        title.setText(dateReceived);

        //start retreiving items consumed on the selected Date
        getDailyItems.run();

        foodAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, filteredArray);
        dayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dailyItems);

        CalorieList = (ListView) findViewById(R.id.ListView_EditMenu);
        dailyItemsList = (ListView) findViewById(R.id.listView_dailyItems);
        registerForContextMenu(CalorieList);
        registerForContextMenu(dailyItemsList);
        CalorieList.setAdapter(foodAdapter);
        if (!dailyItems.isEmpty()) {
            dailyItemsList.setAdapter(dayAdapter);
        }

        //holding your finger over an item will allow you to add it to your daily doses from the list
        CalorieList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                selectedFoodItemObject = (FoodItem) parent.getItemAtPosition(position);
                selectedFoodPortion = (double) selectedFoodItemObject.getFoodSizeAsInt();
                if (MainMenu.userInfo.getInt("Unit_Type", 3) == 0) {
                    foodDescription = selectedFoodItemObject.getFoodDescriptionImperial();
                } else {
                    foodDescription = selectedFoodItemObject.getFoodDescriptionMetric();
                }

                popupHint = selectedFoodItemObject.getPopupHint();
                //little boolean to tell me which dialog to open when clicking edit
                popupDefiner = 1;
                return false;
            }
        });
        //select the item in your daily list
        dailyItemsList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                selectedFoodItemObject = (FoodItem) parent.getItemAtPosition(position);
                selectedFoodName = selectedFoodItemObject.getFoodName();
                selectedFoodCalories = selectedFoodItemObject.getFoodCalories();
                //little boolean to tell me which dialog to open when clicking edit
                popupDefiner = 0;
                return false;
            }
        });
        //Setup for permanent filter watcher
        TextWatcher searchWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchString = s.toString();
                listMonitor.run();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };
        EditText searchBar = (EditText) findViewById(R.id.editText_searchBar);
        searchBar.addTextChangedListener(searchWatcher);

        builder = new AlertDialog.Builder(this);
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
    }

    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        //the oepned menu depends on the last selected item
        if (popupDefiner == 1) {
        	//create the adding of new objects from your database list
            inflater.inflate(R.menu.popup_menu_add, menu);
        } else if (popupDefiner == 0) {
        	//remove when selected from the daily list (if you chose the wrong amount or wrong item)
            inflater.inflate(R.menu.popup_menu_remove, menu);
        } else {

        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.action_bar_everywhere, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.action_help: {
                android.app.AlertDialog.Builder helpPopup = new android.app.AlertDialog.Builder(this);
                TextView alertTitle = new TextView(this);
                alertTitle.setText("Editing Your Day");
                alertTitle.setGravity(Gravity.CENTER_HORIZONTAL);
                alertTitle.setTextSize(20);
                helpPopup.setCustomTitle(alertTitle);
                TextView information = new TextView(this);
                information.setText(R.string.HelpMenu_UsingEditMenu);
                information.setGravity(Gravity.CENTER);
                information.setTextSize(16);
                helpPopup.setView(information);
                helpPopup.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                helpPopup.show();
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_Add:{
                builder.setTitle(R.string.editMenu_PopupTitle);
                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //run thread to write the select portion to database;
                        String userEntry = popupView.getText().toString();
                        if (!userEntry.isEmpty()) {
                            selectedUserPortion = Double.parseDouble(userEntry);
                            addCalendarInfoFood.run();
                            EditText resetText = (EditText) findViewById(R.id.editText_searchBar);
                            resetText.setText("");
                            Toast toast = Toast.makeText(EditMenu.this, "Saved To Day", Toast.LENGTH_SHORT);
                            toast.show();
                        } else {
                            Toast toast = Toast.makeText(EditMenu.this, "Make Sure To Enter A Value!", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    }
                });
                LinearLayout alertDialogLayout = new LinearLayout(this);
                alertDialogLayout.setOrientation(LinearLayout.VERTICAL);
                alertDialogLayout.setGravity(Gravity.CENTER);

                //create description for simplify understanding of food quantities to user
                TextView textDescription = new TextView(this);
                textDescription.setGravity(Gravity.CENTER_HORIZONTAL);
                textDescription.setText(foodDescription);

                //create input bar for them to enter their customized value
                popupView = new EditText(this);
                popupView.setHint(popupHint);
                popupView.setInputType(InputType.TYPE_NUMBER_FLAG_DECIMAL);
                popupView.setRawInputType(InputType.TYPE_CLASS_NUMBER);

                //add both views to the linearLayout(viewGroup)
                alertDialogLayout.addView(textDescription, 0);
                alertDialogLayout.addView(popupView, 1);

                //add linearLayout view to the dialog
                builder.setView(alertDialogLayout);
                builder.show();
                return true;
            }

            case R.id.action_RemoveDb:{
                builder.setTitle("Remove Forever?");
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MainMenu.db.deleteCalorieGuide(selectedFoodItemObject.getFoodName());
                        foodAdapter.remove(selectedFoodItemObject);
                        foodAdapter.notifyDataSetChanged();
                        Toast toast = Toast.makeText(EditMenu.this, "This Item Has Been Removed From The Database", Toast.LENGTH_SHORT);
                        toast.show();
                    }
                });
                builder.show();
                return true;
            }
            case R.id.action_EditDb:{
                Intent openEditor = new Intent(EditMenu.this,AddFoodDatabaseMenu.class);
                openEditor.putExtra("Opener",0);
                startActivity(openEditor);
                return true;
            }
            case R.id.action_Remove:
                removeDailyItem.run();
                Toast toast = Toast.makeText(EditMenu.this, "Removed From Day", Toast.LENGTH_SHORT);
                toast.show();
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
}

