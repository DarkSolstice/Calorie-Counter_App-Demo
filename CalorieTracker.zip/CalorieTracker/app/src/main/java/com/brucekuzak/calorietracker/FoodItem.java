package com.brucekuzak.calorietracker;

/**
 * Created by bruce on 2015-06-16.
 */
public class FoodItem {
	//class for my database objects food items
    private String foodName;
    private String foodSize;
    private int foodCalories;
    private String foodDescriptionMetric;
    private String foodDescriptionImperial;

    private double foodProteins;
    private double foodCarbs;
    private double foodFats;

    //foodItem Constructor
    public FoodItem(String name, String size, int calories, double protein, double carbs, double fat, String descriptionMetric, String descriptionImperial) {
        this.foodName = name;
        this.foodSize = size;
        this.foodCalories = calories;
        this.foodCarbs = carbs;
        this.foodFats = fat;
        this.foodProteins = protein;
        this.foodDescriptionMetric = descriptionMetric;
        this.foodDescriptionImperial = descriptionImperial;
    }

    @Override
    public String toString() {
        if (this.foodSize == null) {
            return this.foodName + " (C:" + this.foodCalories + "/P:" + this.foodProteins + "/S:" + this.foodCarbs + "/F:" + this.foodFats + ")";
        } else {
            if (MainMenu.userInfo.getInt("Unit_Type", 1) == 0) {
                int size = this.getFoodSizeAsInt();
                double foodOunce = size * 0.035;
                return this.foodName + " (C:" + this.foodCalories + "/P:" + this.foodProteins + "/S:" + this.foodCarbs + "/F:" + this.foodFats + ")/" + foodOunce + "oz";
            } else {
                return this.foodName + " (C:" + this.foodCalories + "/P:" + this.foodProteins + "/S:" + this.foodCarbs + "/F:" + this.foodFats + ")/" + this.foodSize;
            }

        }

    }

    public String getFoodName() {
        return this.foodName;
    }

    public int getFoodSizeAsInt() {
        String intString = this.foodSize.replaceAll("\\D+", "");
        return Integer.parseInt(intString);
    }

    public String getPopupHint() {
        if (MainMenu.userInfo.getInt("Unit_Type", 1) == 0) {
            return this.foodCalories + " cal / 3.5oz";
        } else {
            return this.foodCalories + " cal / " + this.foodSize;
        }
    }

    public int getUnitType() {
        String unitString = this.foodSize.replaceAll("\\d","");
        int intReturn =-1;
        if(unitString.equals("g")){
            intReturn = 0;
        }
        else if(unitString.equals("ml")){
            intReturn = 1;
        }
        else if(unitString.equals("unit")){
            intReturn = 2;
        }
        return intReturn;
    }

    public int getFoodCalories() {
        return this.foodCalories;
    }

    public String getFoodDescriptionMetric() {
        return this.foodDescriptionMetric;
    }

    public String getFoodDescriptionImperial() {
        return this.foodDescriptionImperial;
    }

    public double getFoodProteins() {
        return this.foodProteins;
    }

    public double getFoodCarbs() {
        return this.foodCarbs;
    }

    public double getFoodFats() {
        return this.foodFats;
    }

}
