package com.brucekuzak.calorietracker;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;


public class MainMenu extends ActionBarActivity {

	
	//variables accessible throughout the app the database and the userPreferences
    public static SharedPreferences userInfo;
    public static DatabaseHelper db;

    Thread databaseHandler = new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                if (!db.checkDataBase()) {
                    db.create();
                }
                db.open();
                db.getWritableDatabase();
            } catch (Exception ioe) {

            }
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);
        db = new DatabaseHelper(this);
        //this will start the onCreate or onUpgrade methods.
        databaseHandler.run();

        userInfo = getSharedPreferences("userPreferences", 0);
        SharedPreferences.Editor initializer = userInfo.edit();
        //default 1 = metric system;
        //Load advertisement (was intentionally added for google store purposes)
        AdView mAdView = (AdView) findViewById(R.id.adView_mainMenu_Banner);
        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice(AdRequest.DEVICE_ID_EMULATOR).build();
        mAdView.loadAd(adRequest);
        boolean hasSetProfile = userInfo.getBoolean("hasSetProfile", false);
        if (!hasSetProfile) {
        	//adding a note to setup profile first (this helps the app better tell you your actual stats)
            LinearLayout mainList = (LinearLayout) findViewById(R.id.mainMenu_menuListLayout);
            TextView profileStatusText = new TextView(this);
            profileStatusText.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            profileStatusText.setGravity(Gravity.CENTER);
            profileStatusText.setText("Start By Setting Up Your Profile");
            mainList.addView(profileStatusText, 3);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.action_bar_main_menu, menu);
        return true;
    }
    //this is the preferences menu setup where the boxes is created and everything will be saved when exiting
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_Settings: {
                AlertDialog.Builder settingsDialog = new AlertDialog.Builder(this);
                settingsDialog.setTitle("Choose Your Preferred Unit of Measurement");
                final RadioGroup measurementGroup = new RadioGroup(this);
                RadioButton metricButton = new RadioButton(this);
                metricButton.setText("metric");
                metricButton.setId(R.id.radioButton_settingsDialog_metric);
                RadioButton imperialButton = new RadioButton(this);
                imperialButton.setText("imperial");
                imperialButton.setId(R.id.radioButton_settingsDialog_imperial);
                measurementGroup.addView(metricButton, 0);
                measurementGroup.addView(imperialButton, 1);
                measurementGroup.setOrientation(LinearLayout.HORIZONTAL);
                measurementGroup.setGravity(Gravity.CENTER_HORIZONTAL);
                settingsDialog.setView(measurementGroup);
                settingsDialog.setPositiveButton("Apply", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SharedPreferences.Editor measurementChange = userInfo.edit();
                        if (((RadioButton) (measurementGroup.findViewById(R.id.radioButton_settingsDialog_metric))).isChecked()) {
                            measurementChange.putInt("Unit_Type", 1);
                            measurementChange.apply();
                        } else if (((RadioButton) (measurementGroup.findViewById(R.id.radioButton_settingsDialog_imperial))).isChecked()) {
                            measurementChange.putInt("Unit_Type", 0);
                            measurementChange.apply();
                        } else {
                        }
                    }
                });
                settingsDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //does Nothing only closes;
                    }
                });
                settingsDialog.show();
            }
        }

        return super.onOptionsItemSelected(item);
    }
    
    //button to change to other windows coding isolated in functions
    public void navigateAddDatabase(View view) {
        Intent openAddDatabaseMenu = new Intent(this, AddFoodDatabaseMenu.class);
        openAddDatabaseMenu.putExtra("Opener",1);
        startActivity(openAddDatabaseMenu);
    }

    public void navigateProfileMenu(View view) {
        Intent openProfileMenu = new Intent(this, ProfileMenu.class);
        startActivity(openProfileMenu);
    }

    public void navigateStatisticsMenu(View view) {
        Intent openStatisticsMenu = new Intent(this, StatisticsMenu.class);
        startActivity(openStatisticsMenu);
    }

    public void nagivateCalendarMenu(View view) {
        Intent openCalendarMenu = new Intent(this, CalendarMenu.class);
        startActivity(openCalendarMenu);
    }
}
