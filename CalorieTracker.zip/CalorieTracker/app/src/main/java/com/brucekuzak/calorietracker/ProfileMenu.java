package com.brucekuzak.calorietracker;
/*
updated code added thread to speed up application
updated code switched the userPreferences from a database to sharedPreferences
updated code on 24/06/15 for easier reading and less lines
updated code on 22/07/15 for metric/imperial units

 */

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;


public class ProfileMenu extends ActionBarActivity {
    //user info saved to be used all over the class;
    private int userAge,userWeight,userHeight,userGender,userActivity,userCalories,userGoals,userMeasurement,userProtein,userCarbs,userFats;
    private float userWeightGoals;
    private boolean hasSetProfile;
    //preference
    //update sharedPreferences
    Thread updateUserPreferences = new Thread(new Runnable() {
        @Override
        public void run() {
            SharedPreferences.Editor editor = MainMenu.userInfo.edit();
            editor.putInt("userAge", userAge);
            editor.putInt("userWeight", userWeight);
            editor.putInt("userHeight", userHeight);
            editor.putInt("userGender", userGender);
            editor.putInt("userActivity", userActivity);
            editor.putInt("userCalories", userCalories);
            editor.putInt("userGoals", userGoals);
            editor.putInt("userCarbs", userCarbs);
            editor.putInt("userFats", userFats);
            editor.putInt("userProtein", userProtein);
            editor.putFloat("userWeightGoals", userWeightGoals);
            editor.putBoolean("hasSetProfile", hasSetProfile);
            editor.apply();
        }
    });

    //get user information from sharedPreferences
    Thread getUserPreferences = new Thread(new Runnable() {
        @Override
        public void run() {
            userAge = MainMenu.userInfo.getInt("userAge", -1);
            userWeight = MainMenu.userInfo.getInt("userWeight", -1);
            userHeight = MainMenu.userInfo.getInt("userHeight", -1);
            userGender = MainMenu.userInfo.getInt("userGender", 2);
            userActivity = MainMenu.userInfo.getInt("userActivity", -1);
            userCalories = MainMenu.userInfo.getInt("userCalories", -1);
            userGoals = MainMenu.userInfo.getInt("userGoals", 5);
            userMeasurement = MainMenu.userInfo.getInt("Unit_Type", 1);
            userCarbs = MainMenu.userInfo.getInt("userCarbs", -1);
            userFats = MainMenu.userInfo.getInt("userFats", -1);
            userProtein = MainMenu.userInfo.getInt("userProtein", -1);
            userWeightGoals = MainMenu.userInfo.getFloat("userWeightGoals", -1);
            hasSetProfile = MainMenu.userInfo.getBoolean("hasSetProfile", false);
        }
    });

    //moved to thread to speed up ui, reduce action on main thread.
    Thread getDailyCalorieCount = new Thread(new Runnable() {
        @Override
        public void run() {
            //thread variables
            double multiplier = 0;
            int bmr;
            boolean emptyCheck = false;

            //get info from weight age and height
            String userAgeString = (((EditText) findViewById(R.id.editTextAge)).getText().toString());
            String userWeightString = (((EditText) findViewById(R.id.editTextWeight)).getText().toString());
            String userHeightString = (((EditText) findViewById(R.id.editTextHeight)).getText().toString());
            String userCarbsString = (((EditText) findViewById(R.id.editText_profileMenu_Carbs)).getText().toString());
            String userProteinString = (((EditText) findViewById(R.id.editText_profileMenu_Protein)).getText().toString());
            String userFatsString = (((EditText) findViewById(R.id.editText_profileMenu_Fats)).getText().toString());
            String userWeightGoalsString = (((EditText) findViewById(R.id.editTextWeeklyDifference)).getText().toString());

            if (!(userAgeString.isEmpty() || userWeightString.isEmpty() || userHeightString.isEmpty() || userCarbsString.isEmpty() || userProteinString.isEmpty() || userFatsString.isEmpty()|| userWeightGoalsString.isEmpty())) {
                userAge = Integer.parseInt(userAgeString);
                userWeight = Integer.parseInt(userWeightString);
                userHeight = Integer.parseInt(userHeightString);
                userCarbs = Integer.parseInt(userCarbsString);
                userProtein = Integer.parseInt(userProteinString);
                userFats = Integer.parseInt(userFatsString);
                userWeightGoals = (float)(Double.parseDouble(userWeightGoalsString));
                emptyCheck = true;
            }
            //get goal level
            if (((RadioButton) findViewById(R.id.Button_lose)).isChecked()) {
                userGoals = -1;
            } else if (((RadioButton) findViewById(R.id.Button_Maintain)).isChecked()) {
                userGoals = 0;
            } else if (((RadioButton) findViewById(R.id.Button_Gain)).isChecked()) {
                userGoals = 1;
            } else {/*donothing*/}

            //get gender
            RadioButton genderMale = (RadioButton) findViewById(R.id.radioButtonMale);
            // Is Male Checked?
            boolean maleTrue = genderMale.isChecked();
            RadioButton genderFemale = (RadioButton) findViewById(R.id.radioButtonFemale);
            // is Female Checked?
            boolean femaleTrue = genderFemale.isChecked();

            // get activity level from radio buttons
            if (((RadioButton) findViewById(R.id.radioButtonExNone)).isChecked()) {
                multiplier = 1.15;
                userActivity = 1;
            } else if (((RadioButton) findViewById(R.id.radioButtonExLow)).isChecked()) {
                multiplier = 1.375;
                userActivity = 2;
            } else if (((RadioButton) findViewById(R.id.radioButtonMed)).isChecked()) {
                multiplier = 1.55;
                userActivity = 3;
            } else if (((RadioButton) findViewById(R.id.radioButtonExHigh)).isChecked()) {
                multiplier = 1.725;
                userActivity = 4;
            } else if (((RadioButton) findViewById(R.id.radioButtonExExtr)).isChecked()) {
                multiplier = 1.9;
                userActivity = 5;
            } else {
                multiplier = 0;
                hasSetProfile = false;
            }

            //Different calculations used for male/female
            if (maleTrue) {
                if (userMeasurement == 0) {
                    bmr = (int) (66 + 6.21 * userWeight + 12.7 * userHeight - 6.8 * userAge);
                } else {
                    bmr = (int) (66 + 13.7 * userWeight + 5 * userHeight - 6.8 * userAge);
                }
                userCalories = (int) (bmr * multiplier);
                userGender = 1;
            } else if (femaleTrue) {
                if (userMeasurement == 0) {
                    bmr = (int) (655 + 4.35 * userWeight + 4.57 * userHeight - 4.7 * userAge);
                } else {
                    bmr = (int) (655 + 9.6 * userWeight + 1.8 * userHeight - 4.7 * userAge);
                }
                userCalories = (int) (bmr * multiplier);
                userGender = 0;
            } else {
                hasSetProfile = false;
            }
            if (userCalories > 0 && emptyCheck && (userCarbs + userProtein + userFats) == 100) {
                hasSetProfile = true;
            }
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_menu);

        getUserPreferences.run();
        if (userMeasurement == 0) {
            ((TextView) findViewById(R.id.textViewWeight)).setText(R.string.profileMenu_WeightQuestion_Imperial);
            ((TextView) findViewById(R.id.textViewHeight)).setText(R.string.profileMenu_HeightQuestion_Imperial);
            ((TextView)findViewById(R.id.textViewWeeklyDifference)).setText(R.string.profileMenu_WeeklyDifference_Imperial);
        }
        //This whole procedure should assure the saved database info is set as values in the menu
        //reset database text in slots these should be inputted all in database or else it will never update on click
        if (hasSetProfile) {
            ((EditText) findViewById(R.id.editTextAge)).setText(Integer.toString(userAge));
            ((EditText) findViewById(R.id.editTextWeight)).setText(Integer.toString(userWeight));
            ((EditText) findViewById(R.id.editTextHeight)).setText(Integer.toString(userHeight));
            ((TextView) findViewById(R.id.textViewDailyIntakeResult)).setText(Integer.toString(userCalories));
            ((EditText) findViewById(R.id.editText_profileMenu_Carbs)).setText(Integer.toString(userCarbs));
            ((EditText) findViewById(R.id.editText_profileMenu_Protein)).setText(Integer.toString(userProtein));
            ((EditText) findViewById(R.id.editText_profileMenu_Fats)).setText(Integer.toString(userFats));
            ((EditText) findViewById(R.id.editTextWeeklyDifference)).setText(Float.toString(userWeightGoals));
            //set selected gender from sharedPreferences 0=male 1=female.
            switch (userGender) {
                case 0:
                    ((RadioButton) findViewById(R.id.radioButtonFemale)).setChecked(true);
                    break;
                case 1:
                    ((RadioButton) findViewById(R.id.radioButtonMale)).setChecked(true);
                    break;
            }

            // set the correct activity level according to integer set sharedPreferences
            switch (userActivity) {
                case 1:
                    ((RadioButton) findViewById(R.id.radioButtonExNone)).setChecked(true);
                    break;
                case 2:
                    ((RadioButton) findViewById(R.id.radioButtonExLow)).setChecked(true);
                    break;
                case 3:
                    ((RadioButton) findViewById(R.id.radioButtonMed)).setChecked(true);
                    break;
                case 4:
                    ((RadioButton) findViewById(R.id.radioButtonExHigh)).setChecked(true);
                    break;
                case 5:
                    ((RadioButton) findViewById(R.id.radioButtonExExtr)).setChecked(true);
                    break;
            }
            switch (userGoals) {
                case -1:
                    ((RadioButton) findViewById(R.id.Button_lose)).setChecked(true);
                    if(userMeasurement==0){
                        ((TextView) findViewById(R.id.textViewDailyIntakeResult)).setText(((int)(userCalories-userWeightGoals*3500/7))+" - "+userCalories);
                    }
                    else{
                        ((TextView) findViewById(R.id.textViewDailyIntakeResult)).setText(((int)(userCalories-userWeightGoals*7700/7))+" - "+userCalories);
                    }
                    break;
                case 0:
                    ((RadioButton) findViewById(R.id.Button_Maintain)).setChecked(true);
                    ((TextView) findViewById(R.id.textViewDailyIntakeResult)).setText(Integer.toString(userCalories));
                    break;
                case 1:
                    ((RadioButton) findViewById(R.id.Button_Gain)).setChecked(true);
                    if(userMeasurement==0){
                        ((TextView) findViewById(R.id.textViewDailyIntakeResult)).setText(userCalories+" - "+((int)(userCalories+userWeightGoals*3500/7)));
                    }
                    else{
                        ((TextView) findViewById(R.id.textViewDailyIntakeResult)).setText(userCalories+" - "+((int)(userCalories+userWeightGoals*7700/7)));
                    }
                    break;
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.action_bar_everywhere, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_help: {
                AlertDialog.Builder helpPopup = new AlertDialog.Builder(this);
                TextView alertTitle = new TextView(this);
                alertTitle.setText("Profile Setup");
                alertTitle.setGravity(Gravity.CENTER_HORIZONTAL);
                alertTitle.setTextSize(20);
                helpPopup.setCustomTitle(alertTitle);
                TextView information = new TextView(this);
                information.setText(R.string.HelpMenu_ProfileSetup);
                information.setGravity(Gravity.CENTER);
                information.setTextSize(16);
                helpPopup.setView(information);
                helpPopup.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                helpPopup.show();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    public void calculateCalories(View view) {
        getDailyCalorieCount.run();

        TextView avgDailyIntake = (TextView) findViewById(R.id.textViewDailyIntakeResult);
        if (hasSetProfile) {
            String calorieInterval = "";
            int desiredDailyDifference;
            switch(userGoals){
                case -1:{
                    if(userMeasurement == 0){
                        desiredDailyDifference = (int)(userWeightGoals*3500/7);
                    }
                    else{
                        desiredDailyDifference = (int)(userWeightGoals*7700/7);
                    }
                    int lowestValue = userCalories-desiredDailyDifference;
                    calorieInterval = lowestValue + " - " + userCalories;
                    break;
                }
                case 0:{
                    calorieInterval = "~"+userCalories;
                    break;
                }
                case 1:{
                    if(userMeasurement == 0){
                        desiredDailyDifference = (int)(userWeightGoals*3500/7);
                    }
                    else{
                        desiredDailyDifference = (int)(userWeightGoals*7700/7);
                    }
                    int highestValue = userCalories+desiredDailyDifference;
                    calorieInterval = userCalories+ " - "+highestValue;
                    break;
                }
            }
            avgDailyIntake.setText(calorieInterval);
            updateUserPreferences.run();
            Toast updated = Toast.makeText(this, "Updated", Toast.LENGTH_SHORT);
            updated.show();
        } else {
            avgDailyIntake.setText("Make Sure everything is filled-in and the total of the Diet Setup = 100%");
        }
    }
}
