package com.brucekuzak.calorietracker;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.jjoe64.graphview.DefaultLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.ValueDependentColor;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;


public class StatisticsMenu extends ActionBarActivity {

    //Date Variables shared across the activity
    private String monthTitle;
    private int monthInt;
    private int daysInCurrentMonth;
    private int currentYear;
    private Calendar rightNow;

    //variables pertaining to the users information to build correct statistics
    private int userCalories,userProteins,userFats,userCarbs,userGoals;
    private int macroType = 1;
    private float userWeightGoals;
    private int userMeasurement;
    private int daysWithValues;

    //variable and stuff for monthlyList total
    private ListView monthlyTotals;
    private ArrayAdapter<String> monthlyAdapter;
    private ArrayList<String> adapterArray = new ArrayList<>();
    //variable for graph
    private DataPoint[] barPoints;
    private BarGraphSeries<DataPoint> barSeries;
    private GraphView barGraph;
    private TextView graphTitle;
    private TextView macroTitle;

    Thread listSetup = new Thread(new Runnable() {
        @Override
        public void run() {
            int calorieTotal = 0;
            double proteinTotal = 0;
            double carbsTotal = 0;
            double fatTotal = 0;
            double[] dailyTotals;
            String formattedDate = "";
            DecimalFormat df = new DecimalFormat("0.00");
            for (int i = 1; i <= 31; i++) {
                try {
                    if (i <= 9 && monthInt <= 9) {
                        formattedDate = "0" + i + "0" + monthInt + "" + currentYear;
                    } else if (monthInt <= 9) {
                        formattedDate = i + "0" + monthInt + "" + currentYear;
                    } else if (i <= 9) {
                        formattedDate = "0" + i + "" + monthInt + "" + currentYear;
                    }

                    dailyTotals = MainMenu.db.getDateInfoSum(formattedDate);
                    calorieTotal += dailyTotals[0];
                    proteinTotal += dailyTotals[1];
                    carbsTotal += dailyTotals[2];
                    fatTotal += dailyTotals[3];
                } catch (Exception ioe) {

                }
            }
            int recommendedCalories = daysWithValues*userCalories;
            double recommendedProteins = ((userCalories*(userProteins/100.0))/4)*daysWithValues;
            double recommendedFats = ((userCalories*(userFats/100.0))/9)*daysWithValues;
            double recommendedCarbs = ((userCalories*(userCarbs/100.0))/4)*daysWithValues;
            int calorieDifference = calorieTotal - recommendedCalories;
            String proteinDifference = df.format(proteinTotal-recommendedProteins);
            String carbsDifference = df.format(carbsTotal-recommendedCarbs);
            String fatsDifference = df.format(fatTotal-recommendedFats);

            adapterArray.clear();
            adapterArray.add("Calories : " + calorieTotal +" ("+ calorieDifference +")");
            adapterArray.add("Proteins : " + df.format(proteinTotal) + " ("+ proteinDifference+")");
            adapterArray.add("Carbs : " + df.format(carbsTotal) + " ("+carbsDifference+")");
            adapterArray.add("Fats : " + df.format(fatTotal) + " ("+fatsDifference+")");
            monthlyAdapter.notifyDataSetChanged();
        }
    });

    Thread graphSetup = new Thread(new Runnable() {
        @Override
        public void run() {
            switch (monthInt) {
                case 1: monthTitle = "Jan"; break;
                case 2: monthTitle = "Feb";break;
                case 3:monthTitle = "Mar";break;
                case 4:monthTitle = "Apr";break;
                case 5:monthTitle = "May";break;
                case 6:monthTitle = "Jun";break;
                case 7:monthTitle = "Jul";break;
                case 8:monthTitle = "Aug";break;
                case 9:monthTitle = "Sep";break;
                case 10:monthTitle = "Oct";break;
                case 11:monthTitle = "Nov";break;
                case 12:monthTitle = "Dec";break;
            }
            try {
                //CHeck month days Calendar has no method that i know of doing this;
                //ALso set up the X axis depending on the number of Days.
                if (monthInt == 4 || monthInt == 6 || monthInt == 9 || monthInt == 11) {
                    daysInCurrentMonth = 30;
                } else if (monthInt == 2) {
                    daysInCurrentMonth = 28;
                } else {
                    daysInCurrentMonth = 31;
                }
                if(monthInt<=9){
                    daysWithValues = MainMenu.db.getNumberOfDaysEnteredInMonth("0"+monthInt,daysInCurrentMonth,""+currentYear);
                }
                else{
                    daysWithValues = MainMenu.db.getNumberOfDaysEnteredInMonth(""+monthInt, daysInCurrentMonth, ""+currentYear);
                }
                //Get the datapoint using data fromt the database and method from database Helper
                switch (macroType % 4) {
                    case 1: {
                        if (monthInt <= 9) {
                            barPoints = MainMenu.db.getMonthDailyCalorieSum("0" + monthInt, daysInCurrentMonth, "" + currentYear);
                        } else {
                            barPoints = MainMenu.db.getMonthDailyCalorieSum("" + monthInt, daysInCurrentMonth, "" + currentYear);
                        }
                        break;
                    }
                    case 2: {
                        if (monthInt <= 9) {
                            barPoints = MainMenu.db.getMonthDailyProteinSum("0" + monthInt, daysInCurrentMonth, "" + currentYear);
                        } else {
                            barPoints = MainMenu.db.getMonthDailyProteinSum("" + monthInt, daysInCurrentMonth, "" + currentYear);
                        }
                        break;
                    }
                    case 3: {
                        if (monthInt <= 9) {
                            barPoints = MainMenu.db.getMonthDailySugarSum("0" + monthInt, daysInCurrentMonth, "" + currentYear);
                        } else {
                            barPoints = MainMenu.db.getMonthDailySugarSum("" + monthInt, daysInCurrentMonth, "" + currentYear);
                        }
                        break;
                    }
                    case 0: {
                        if (monthInt <= 9) {
                            barPoints = MainMenu.db.getMonthDailyFatSum("0" + monthInt, daysInCurrentMonth, "" + currentYear);
                        } else {
                            barPoints = MainMenu.db.getMonthDailyFatSum("" + monthInt, daysInCurrentMonth, "" + currentYear);
                        }
                        break;
                    }
                }
            } catch (Exception ioe) {
            }
        }
    });

    //Will setup the correct color for the bars
    Thread graphBarColorSetup = new Thread(new Runnable() {
        @Override
        public void run() {
            barSeries.setValueDependentColor(new ValueDependentColor<DataPoint>() {
                @Override
                public int get(DataPoint data) {
                    if (MainMenu.userInfo.getBoolean("hasSetProfile", false) && data.getY()!=0) {
                        int temp;
                        double yValue = data.getY();
                        switch (macroType % 4) {
                            case 1: {
                                // green bar for lower than 0.9x calories when trying to lose and higher than 1.1x calories when trying to gain
                                // and in between a 10% gain or loss when trying to maintain.
                                if ((userGoals == -1 && yValue <= userCalories && ((yValue>=userCalories-userWeightGoals*3500/7.0 && userMeasurement==0)||(yValue>=userCalories-userWeightGoals*7700/7.0 && userMeasurement==1))) ||
                                    (userGoals == 1 && yValue >= userCalories && ((yValue<=userCalories+userWeightGoals*3500/7.0 && userMeasurement==0)||(yValue<=userCalories+userWeightGoals*7700/7.0 && userMeasurement==1))) ||
                                    (userGoals == 0 && (yValue <= userCalories * 1.1 && yValue >= userCalories * 0.9))) {
                                    return Color.rgb(75, 225, 0);
                                }
                                // red bar for 1.1x calories when trying to lose and 0.9x calories when trying to gain
                                // and if the user exceeds the 10% gain or loss calories when trying to maintain.
                                else{
                                    return Color.rgb(225, 75, 0);
                                }
                            }
                            case 2: {
                                temp = (int) (userCalories * (userProteins / 100.0)) / 4;
                                int userProteinPercentage = (int) (yValue / temp) * 100;
                                //green bar if protein percentage is between 95-100% which means the user is following there diet of what ever percentage they are using.
                                if ((userProteinPercentage > 95 && userProteinPercentage < 105)) {
                                    return Color.rgb(75, 225, 0);
                                } else {
                                    return Color.rgb(225, 75, 0);
                                }
                            }
                            case 3: {
                                temp = (int) (userCalories * (userCarbs / 100.0)) / 4;
                                int userCarbsPercentage = (int) (yValue / temp) * 100;
                                //green bar if protein percentage is between 95-100% which means the user is following there diet of what ever percentage they are using.
                                if ((userCarbsPercentage > 95 && userCarbsPercentage < 105)) {
                                    return Color.rgb(75, 225, 0);
                                } else {
                                    return Color.rgb(225, 75, 0);
                                }
                            }
                            case 0: {
                                temp = (int) (userCalories * (userFats / 100.0)) / 9;
                                int userCarbsPercentage = (int) (yValue / temp) * 100;
                                //green bar if protein percentage is between 95-100% which means the user is following there diet of what ever percentage they are using.
                                if ((userCarbsPercentage > 95 && userCarbsPercentage < 105)) {
                                    return Color.rgb(75, 225, 0);
                                } else {
                                    return Color.rgb(225, 75, 0);
                                }
                            }

                        }
                    }
                    return Color.rgb(0, 75, 255);
                }
            });
        }
    });


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics_menu);

        //get the users profile values
        userCalories = MainMenu.userInfo.getInt("userCalories", -1);
        userProteins = MainMenu.userInfo.getInt("userProtein", -1);
        userCarbs = MainMenu.userInfo.getInt("userCarbs", -1);
        userFats = MainMenu.userInfo.getInt("userFats", -1);
        userGoals = MainMenu.userInfo.getInt("userGoals", 5);
        userWeightGoals = MainMenu.userInfo.getFloat("userWeightGoals", -1);
        userMeasurement = MainMenu.userInfo.getInt("Unit_Type", 1);

        macroTitle = (TextView) findViewById(R.id.textView_StatisticMenu_MacroType);
        macroTitle.setText("Calories");

        //Setup the month and year of the user
        this.rightNow = Calendar.getInstance();
        this.monthInt = rightNow.get(rightNow.MONTH) + 1;
        currentYear = rightNow.get(rightNow.YEAR);
        monthlyTotals = (ListView) findViewById(R.id.listView_StatisticeMenu_MonthlyTotals);
        monthlyAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, adapterArray);
        monthlyTotals.setAdapter(monthlyAdapter);

        //Graph Initial setup for current month and year on device
        this.barGraph = new GraphView(this);
        this.barGraph.getViewport().setXAxisBoundsManual(true);
        this.barGraph.getViewport().setMinX(0);
        this.barGraph.getViewport().setMaxX(8);
        this.barGraph.getGridLabelRenderer().setNumHorizontalLabels(8);

        this.barGraph.getViewport().setScrollable(true);
        this.barGraph.getGridLabelRenderer().setHorizontalAxisTitle("Day");
        this.barGraph.getGridLabelRenderer().setVerticalAxisTitle("Calories");
        this.barGraph.getGridLabelRenderer().setGridStyle(GridLabelRenderer.GridStyle.NONE);
        // Set to display the X as only a integer instead of a double.
        NumberFormat numFormat = NumberFormat.getInstance();
        numFormat.setMaximumFractionDigits(0);
        this.barGraph.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter(numFormat, numFormat));
        //just to initialize before hand it will bechanged when graphSetup is ran.

        //Run thread to calculate DataPoints for graph and other little things
        graphSetup.run();

        //Display top portion initially to correct month
        this.graphTitle = (TextView) findViewById(R.id.textView_graphTitle);
        graphTitle.setText(monthTitle + " " + currentYear);
        this.barSeries = new BarGraphSeries<DataPoint>(barPoints);

        //Run thread to get right colors
        graphBarColorSetup.run();

        //moved this lower to know how many days have values;
        listSetup.run();
        //Set values on topBlack
        barSeries.setDrawValuesOnTop(true);
        barSeries.setValuesOnTopColor(getResources().getColor(android.R.color.black));
        barGraph.addSeries(barSeries);
        barSeries.setSpacing(25);

        //declare linear layout already prepped in XML and add the graph view created
        LinearLayout graphHolder = (LinearLayout) findViewById(R.id.GraphViewHolder);
        graphHolder.addView(barGraph);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.action_bar_everywhere, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_help: {
                AlertDialog.Builder helpPopup = new AlertDialog.Builder(this);
                TextView alertTitle = new TextView(this);
                alertTitle.setText("Using The Statistics Menu");
                alertTitle.setGravity(Gravity.CENTER_HORIZONTAL);
                alertTitle.setTextSize(20);
                helpPopup.setCustomTitle(alertTitle);
                TextView information = new TextView(this);
                information.setText(R.string.HelpMenu_UsingStatistics);
                information.setGravity(Gravity.CENTER);
                information.setTextSize(16);
                helpPopup.setView(information);
                helpPopup.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                helpPopup.show();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    public void reduceMonth(View v) {
        if (this.monthInt == 1) {
            this.currentYear--;
            this.monthInt = 12;
        } else {
            this.monthInt--;
        }
        graphSetup.run();
        listSetup.run();
        graphTitle.setText(monthTitle + " " + currentYear);
        barGraph.onDataChanged(true, false);
        barSeries.resetData(barPoints);
    }

    public void increaseMonth(View v) {
        if (this.monthInt == 12) {
            this.currentYear++;
            this.monthInt = 1;
        } else {
            this.monthInt++;
        }
        graphSetup.run();
        graphBarColorSetup.run();
        listSetup.run();
        graphTitle.setText(monthTitle + " " + currentYear);
        barGraph.onDataChanged(true, false);
        barSeries.resetData(barPoints);

    }

    public void changeMacroType(View v) {
        macroType++;
        graphSetup.run();
        graphBarColorSetup.run();
        switch (macroType % 4) {
            case 1:
                macroTitle.setText("Calories");
                break;
            case 2:
                macroTitle.setText("Proteins");
                break;
            case 3:
                macroTitle.setText("Carbs");
                break;
            case 0:
                macroTitle.setText("Fats");
                break;
        }

        barGraph.onDataChanged(true, false);
        barSeries.resetData(barPoints);
    }
}
